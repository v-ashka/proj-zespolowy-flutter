import 'package:flutter/material.dart';

// basic color app

const primaryCol = Color(0xff42a2ba);
//background color grey-white
const primaryBgCol = Color(0xffdedede);
// secondary color
const secondaryCol = Color(0xff254980);